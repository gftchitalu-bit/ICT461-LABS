/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ledger: {
          ink: '#141b2e',      // near-black navy, "official document" ground
          navy: '#1c2b4a',     // primary institutional color
          navylight: '#2e4270',
          gold: '#b8902f',     // seal / wax-stamp gold accent
          goldlight: '#d9b45c',
          parchment: '#f6f2e9',// certificate paper tone
          verified: '#1f7a4d',
          revoked: '#a3283f',
          slate: '#5b6478',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        'seal-lines': 'repeating-linear-gradient(135deg, rgba(184,144,47,0.06) 0px, rgba(184,144,47,0.06) 1px, transparent 1px, transparent 12px)',
      },
    },
  },
  plugins: [],
}
