import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import { useAuth } from './context/AuthContext'

import Login from './pages/Login'
import VerifyPortal from './pages/VerifyPortal'
import RegistrarDashboard from './pages/registrar/RegistrarDashboard'
import StudentDashboard from './pages/student/StudentDashboard'
import EmployerDashboard from './pages/employer/EmployerDashboard'
import AdminDashboard from './pages/admin/AdminDashboard'
import ProtectedRoute from './components/ProtectedRoute'

function HomeRedirect() {
  const { user } = useAuth()
  if (!user) return <Navigate to="/verify" replace />
  const path = { STUDENT: '/student', REGISTRAR: '/registrar', ADMIN: '/admin', EMPLOYER: '/employer' }[user.role] || '/verify'
  return <Navigate to={path} replace />
}

export default function App() {
  return (
    <div className="min-h-screen bg-ledger-parchment bg-seal-lines">
      <Navbar />
      <main className="max-w-6xl mx-auto px-6 py-8">
        <Routes>
          <Route path="/" element={<HomeRedirect />} />
          <Route path="/login" element={<Login />} />

          {/* Public verification surface - QR scans land on /verify/:uid,
              shareable links land on /verify/link/:token */}
          <Route path="/verify" element={<VerifyPortal />} />
          <Route path="/verify/:certificateUid" element={<VerifyPortal />} />
          <Route path="/verify/link/:token" element={<VerifyPortal />} />

          <Route path="/registrar" element={
            <ProtectedRoute allowedRoles={['REGISTRAR']}>
              <RegistrarDashboard />
            </ProtectedRoute>
          } />

          <Route path="/student" element={
            <ProtectedRoute allowedRoles={['STUDENT']}>
              <StudentDashboard />
            </ProtectedRoute>
          } />

          <Route path="/employer" element={
            <ProtectedRoute allowedRoles={['EMPLOYER']}>
              <EmployerDashboard />
            </ProtectedRoute>
          } />

          <Route path="/admin" element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
              <AdminDashboard />
            </ProtectedRoute>
          } />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <footer className="text-center text-xs text-ledger-slate py-8">
        Mulungushi University &middot; CertChain Credential Platform &middot; Permissioned Ledger Architecture
      </footer>
    </div>
  )
}
