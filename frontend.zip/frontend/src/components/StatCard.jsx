import React from 'react'

export default function StatCard({ label, value, accent = 'navy', suffix }) {
  const accentClass = {
    navy: 'text-ledger-navy',
    gold: 'text-ledger-gold',
    verified: 'text-ledger-verified',
    revoked: 'text-ledger-revoked',
  }[accent]

  return (
    <div className="card p-5">
      <div className="label-eyebrow mb-2">{label}</div>
      <div className={`font-display text-3xl ${accentClass}`}>
        {value}
        {suffix && <span className="text-base ml-1 text-ledger-slate">{suffix}</span>}
      </div>
    </div>
  )
}
