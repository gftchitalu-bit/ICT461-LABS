import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  function handleLogout() {
    logout()
    navigate('/login')
  }

  const dashboardPath = user
    ? { STUDENT: '/student', REGISTRAR: '/registrar', EMPLOYER: '/employer', ADMIN: '/admin' }[user.role] || '/'
    : '/'

  return (
    <header className="bg-ledger-navy text-ledger-parchment border-b-2 border-ledger-gold/40">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to={dashboardPath} className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full border-2 border-ledger-gold flex items-center justify-center font-display text-ledger-gold text-sm">
            MU
          </div>
          <div>
            <div className="font-display text-lg leading-none">CertChain</div>
            <div className="text-[10px] tracking-[0.25em] uppercase text-ledger-goldlight/80">Mulungushi University</div>
          </div>
        </Link>

        {user && (
          <nav className="flex items-center gap-6 text-sm">
            <span className="text-ledger-parchment/70">
              {user.fullName} <span className="badge badge-neutral ml-2 bg-white/10 text-ledger-goldlight">{user.role}</span>
            </span>
            <button onClick={handleLogout} className="text-ledger-goldlight hover:text-white transition-colors">
              Sign out
            </button>
          </nav>
        )}
      </div>
    </header>
  )
}
