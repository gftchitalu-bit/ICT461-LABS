import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:8080/api',
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('certchain_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const isLoginCall = error.config && error.config.url && error.config.url.includes('/auth/login')
    if (error.response && error.response.status === 401 && !isLoginCall) {
      localStorage.removeItem('certchain_token')
      localStorage.removeItem('certchain_user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
