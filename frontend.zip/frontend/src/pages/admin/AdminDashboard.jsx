import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import StatCard from '../../components/StatCard'

const TABS = ['Users', 'Ledger Health', 'Audit Logs']
const STAFF_ROLES = ['REGISTRAR', 'FACULTY', 'EMPLOYER', 'ADMIN']

export default function AdminDashboard() {
  const [tab, setTab] = useState('Users')

  return (
    <div>
      <h1 className="font-display text-2xl text-ledger-navy mb-1">Administration</h1>
      <p className="text-ledger-slate text-sm mb-6">Accounts, access and system health. Admins cannot issue or revoke certificates.</p>

      <div className="flex gap-1 border-b border-black/10 mb-8 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              tab === t ? 'border-ledger-gold text-ledger-navy' : 'border-transparent text-ledger-slate hover:text-ledger-navy'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Users' && <Users />}
      {tab === 'Ledger Health' && <LedgerHealth />}
      {tab === 'Audit Logs' && <AuditLogs />}
    </div>
  )
}

function Users() {
  const [users, setUsers] = useState([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [form, setForm] = useState({ username: '', email: '', fullName: '', role: 'REGISTRAR' })
  const [credential, setCredential] = useState(null)

  async function load(q = '') {
    setLoading(true)
    try {
      const { data } = await api.get('/admin/users', { params: q ? { query: q } : {} })
      setUsers(data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  async function toggle(u) {
    setError('')
    try {
      await api.post(`/admin/users/${u.id}/enabled`, null, { params: { value: !u.enabled } })
      load(query)
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not update the account')
    }
  }

  async function resetPassword(u) {
    if (!window.confirm(`Reset the password for ${u.username}?`)) return
    setError('')
    try {
      const { data } = await api.post(`/admin/users/${u.id}/reset-password`)
      setCredential(data)
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not reset the password')
    }
  }

  async function createUser(e) {
    e.preventDefault()
    setError('')
    try {
      const { data } = await api.post('/admin/users', form)
      setCredential(data)
      setShowCreate(false)
      setForm({ username: '', email: '', fullName: '', role: 'REGISTRAR' })
      load(query)
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not create the account')
    }
  }

  return (
    <div className="space-y-4">
      {error && <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm">{error}</div>}

      {credential && (
        <div className="card p-5 border-t-4 border-ledger-verified text-sm">
          <p className="font-medium mb-1">{credential.message}</p>
          <p>Username: <span className="font-mono">{credential.username}</span></p>
          <p>Temporary password: <span className="font-mono">{credential.temporaryPassword}</span></p>
          <p className="text-xs text-ledger-slate mt-2">Share it securely. It will not be shown again.</p>
          <button className="btn-outline mt-3 text-sm" onClick={() => setCredential(null)}>Dismiss</button>
        </div>
      )}

      <div className="flex gap-2">
        <input className="input-field" placeholder="Search by username, name or email"
               value={query} onChange={(e) => setQuery(e.target.value)}
               onKeyDown={(e) => { if (e.key === 'Enter') load(query) }} />
        <button className="btn-outline" onClick={() => load(query)}>Search</button>
        <button className="btn-gold shrink-0" onClick={() => setShowCreate(true)}>+ Create Account</button>
      </div>

      {loading ? <p className="text-ledger-slate text-sm">Loading…</p> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ledger-navy text-ledger-parchment text-left">
              <tr>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-black/5">
                  <td className="px-4 py-3">{u.fullName}<div className="text-xs text-ledger-slate">{u.username} · {u.email}</div></td>
                  <td className="px-4 py-3 font-mono text-xs">{u.role}</td>
                  <td className="px-4 py-3"><span className={`badge ${u.enabled ? 'badge-verified' : 'badge-revoked'}`}>{u.enabled ? 'Enabled' : 'Disabled'}</span></td>
                  <td className="px-4 py-3 space-x-4 whitespace-nowrap">
                    <button className="text-ledger-navy text-xs underline" onClick={() => resetPassword(u)}>Reset password</button>
                    <button className="text-ledger-revoked text-xs underline" onClick={() => toggle(u)}>{u.enabled ? 'Disable' : 'Enable'}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form onSubmit={createUser} className="card p-6 w-full max-w-sm space-y-4">
            <h3 className="font-display text-lg">Create Account</h3>
            <p className="text-xs text-ledger-slate">Student accounts are created by the Registrar.</p>
            {[['username', 'Username'], ['email', 'Email'], ['fullName', 'Full name']].map(([k, label]) => (
              <div key={k}>
                <label className="label-eyebrow block mb-1.5">{label}</label>
                <input required type={k === 'email' ? 'email' : 'text'} className="input-field" value={form[k]}
                       onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
              </div>
            ))}
            <div>
              <label className="label-eyebrow block mb-1.5">Role</label>
              <select className="input-field" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {STAFF_ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div className="flex gap-2 justify-end">
              <button type="button" className="btn-outline" onClick={() => setShowCreate(false)}>Cancel</button>
              <button type="submit" className="btn-primary">Create</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}

function LedgerHealth() {
  const [health, setHealth] = useState(null)
  const [loading, setLoading] = useState(false)

  async function check() {
    setLoading(true)
    try {
      const { data } = await api.get('/admin/ledger-health')
      setHealth(data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { check() }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button className="btn-primary" onClick={check} disabled={loading}>{loading ? 'Checking…' : 'Run integrity check'}</button>
        {health && <span className="text-xs text-ledger-slate">Last checked {new Date(health.checkedAt).toLocaleString()}</span>}
      </div>

      {health && (
        <>
          <div className="grid sm:grid-cols-3 gap-4">
            <StatCard label="Ledger Integrity" value={health.intact ? 'Intact' : 'FAILED'} accent={health.intact ? 'verified' : 'revoked'} />
            <StatCard label="Total Blocks" value={health.totalBlocks} />
            <StatCard label="Endorsing Peers" value={health.peers.length} accent="gold" />
          </div>
          <div className="card p-6 text-sm space-y-3">
            <div>
              <div className="label-eyebrow mb-1">Peers</div>
              <div className="font-mono text-xs">{health.peers.join(', ')}</div>
            </div>
            <div>
              <div className="label-eyebrow mb-1">Latest block hash</div>
              <div className="font-mono text-xs break-all">{health.latestBlockHash || 'No blocks yet'}</div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function AuditLogs() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/admin/audit-logs').then(({ data }) => setLogs(data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <p className="text-ledger-slate text-sm">Loading…</p>

  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-ledger-navy text-ledger-parchment text-left">
          <tr>
            <th className="px-4 py-3">Actor</th>
            <th className="px-4 py-3">Action</th>
            <th className="px-4 py-3">Target</th>
            <th className="px-4 py-3">Details</th>
            <th className="px-4 py-3">When</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l) => (
            <tr key={l.id} className="border-t border-black/5">
              <td className="px-4 py-3">{l.actorUsername}</td>
              <td className="px-4 py-3 font-mono text-xs">{l.action}</td>
              <td className="px-4 py-3 text-xs">{l.targetType} {l.targetId}</td>
              <td className="px-4 py-3 text-ledger-slate">{l.details}</td>
              <td className="px-4 py-3 text-ledger-slate">{new Date(l.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
