import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import StatCard from '../../components/StatCard'

const TABS = ['Overview', 'Issue Certificate', 'Bulk Issue', 'Certificates', 'Onboard Student', 'Audit Logs']

export default function RegistrarDashboard() {
  const [tab, setTab] = useState('Overview')

  return (
    <div>
      <h1 className="font-display text-2xl text-ledger-navy mb-1">Registrar Console</h1>
      <p className="text-ledger-slate text-sm mb-6">Issue, revoke, and manage credentials on the permissioned ledger.</p>

      <div className="flex gap-1 border-b border-black/10 mb-8 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              tab === t ? 'border-ledger-gold text-ledger-navy' : 'border-transparent text-ledger-slate hover:text-ledger-navy'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && <Overview />}
      {tab === 'Issue Certificate' && <IssueCertificate />}
      {tab === 'Bulk Issue' && <BulkIssue />}
      {tab === 'Certificates' && <Certificates />}
      {tab === 'Onboard Student' && <OnboardStudent />}
      {tab === 'Audit Logs' && <AuditLogs />}
    </div>
  )
}

// ---------------------------------------------------------------------

function Overview() {
  const [stats, setStats] = useState(null)

  useEffect(() => {
    api.get('/registrar/stats').then(({ data }) => setStats(data))
  }, [])

  if (!stats) return <p className="text-ledger-slate text-sm">Loading statistics…</p>

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Certificates Issued" value={stats.totalCertificatesIssued} />
        <StatCard label="Active" value={stats.activeCertificates} accent="verified" />
        <StatCard label="Revoked" value={stats.revokedCertificates} accent="revoked" />
        <StatCard label="Total Verifications" value={stats.totalVerifications} accent="gold" />
        <StatCard label="Verifications (30 days)" value={stats.verificationsLast30Days} />
        <StatCard label="Ledger Blocks" value={stats.totalLedgerBlocks} />
        <StatCard label="Ledger Integrity" value={stats.ledgerIntact ? 'Intact' : 'FAILED'} accent={stats.ledgerIntact ? 'verified' : 'revoked'} />
      </div>

      <div className="card p-6">
        <h3 className="label-eyebrow mb-4">Verifications by Result</h3>
        <div className="space-y-2">
          {Object.entries(stats.verificationsByResult || {}).map(([k, v]) => (
            <div key={k} className="flex justify-between text-sm border-b border-black/5 py-2">
              <span>{k}</span>
              <span className="font-mono">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------

function IssueCertificate() {
  const [form, setForm] = useState({ studentNumber: '', programName: '', classification: '', issueDate: '' })
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const payload = { ...form, issueDate: form.issueDate || null }
      const { data } = await api.post('/registrar/certificates/issue', payload)
      setResult(data)
      setForm({ studentNumber: '', programName: '', classification: '', issueDate: '' })
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not issue certificate')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-lg">
      <form onSubmit={submit} className="card p-6 space-y-4">
        {error && <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm">{error}</div>}
        <div>
          <label className="label-eyebrow block mb-1.5">Student Number</label>
          <input required className="input-field" value={form.studentNumber}
                 onChange={(e) => setForm({ ...form, studentNumber: e.target.value })} />
        </div>
        <div>
          <label className="label-eyebrow block mb-1.5">Program Name</label>
          <input required className="input-field" value={form.programName}
                 onChange={(e) => setForm({ ...form, programName: e.target.value })} placeholder="e.g. Bachelor of Science in Computer Science" />
        </div>
        <div>
          <label className="label-eyebrow block mb-1.5">Classification (optional)</label>
          <input className="input-field" value={form.classification}
                 onChange={(e) => setForm({ ...form, classification: e.target.value })} placeholder="e.g. Distinction" />
        </div>
        <div>
          <label className="label-eyebrow block mb-1.5">Issue Date (optional, defaults to today)</label>
          <input type="date" className="input-field" value={form.issueDate}
                 onChange={(e) => setForm({ ...form, issueDate: e.target.value })} />
        </div>
        <button className="btn-primary w-full" disabled={loading}>{loading ? 'Committing to ledger…' : 'Issue Certificate'}</button>
      </form>

      {result && (
        <div className="card p-6 mt-4 border-t-4 border-ledger-verified">
          <p className="text-sm font-medium">Certificate issued and committed to the permissioned ledger.</p>
          <div className="text-xs font-mono mt-3 space-y-1 text-ledger-slate break-all">
            <div>Certificate ID: {result.certificateUid}</div>
            <div>Transaction ID: {result.transactionId}</div>
            <div>Hash: {result.certificateHash}</div>
          </div>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------

function BulkIssue() {
  const [rows, setRows] = useState([{ studentNumber: '', programName: '', classification: '', issueDate: '' }])
  const [results, setResults] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  function updateRow(i, field, value) {
    const copy = [...rows]
    copy[i][field] = value
    setRows(copy)
  }

  function addRow() {
    setRows([...rows, { studentNumber: '', programName: '', classification: '', issueDate: '' }])
  }

  function removeRow(i) {
    setRows(rows.filter((_, idx) => idx !== i))
  }

  async function submit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setResults(null)
    try {
      const certificates = rows.map((r) => ({ ...r, issueDate: r.issueDate || null }))
      const { data } = await api.post('/registrar/certificates/bulk-issue', { certificates })
      setResults(data)
    } catch (err) {
      setError(err?.response?.data?.message || 'Bulk issuance failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <p className="text-ledger-slate text-sm mb-4">Issue certificates for an entire graduating class in one batch — each still gets its own individually endorsed ledger entry.</p>

      <form onSubmit={submit} className="space-y-4">
        {error && <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm">{error}</div>}
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ledger-navy text-ledger-parchment text-left">
              <tr>
                <th className="px-3 py-2">Student Number</th>
                <th className="px-3 py-2">Program</th>
                <th className="px-3 py-2">Classification</th>
                <th className="px-3 py-2">Issue Date</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-t border-black/5">
                  <td className="px-3 py-2"><input className="input-field" required value={r.studentNumber} onChange={(e) => updateRow(i, 'studentNumber', e.target.value)} /></td>
                  <td className="px-3 py-2"><input className="input-field" required value={r.programName} onChange={(e) => updateRow(i, 'programName', e.target.value)} /></td>
                  <td className="px-3 py-2"><input className="input-field" value={r.classification} onChange={(e) => updateRow(i, 'classification', e.target.value)} /></td>
                  <td className="px-3 py-2"><input type="date" className="input-field" value={r.issueDate} onChange={(e) => updateRow(i, 'issueDate', e.target.value)} /></td>
                  <td className="px-3 py-2">
                    {rows.length > 1 && <button type="button" onClick={() => removeRow(i)} className="text-ledger-revoked text-xs">Remove</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={addRow} className="btn-outline">+ Add Row</button>
          <button type="submit" disabled={loading} className="btn-primary">{loading ? 'Issuing…' : 'Issue All'}</button>
        </div>
      </form>

      {results && (
        <div className="card p-6 mt-6">
          <p className="text-sm font-medium mb-3">{results.length} certificate(s) issued successfully.</p>
          <ul className="text-xs font-mono space-y-1 text-ledger-slate">
            {results.map((r) => <li key={r.id}>{r.studentNumber} — {r.certificateUid}</li>)}
          </ul>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------

function Certificates() {
  const [query, setQuery] = useState('')
  const [certs, setCerts] = useState([])
  const [loading, setLoading] = useState(true)
  const [revokeTarget, setRevokeTarget] = useState(null)
  const [reason, setReason] = useState('')

  async function load(q) {
    setLoading(true)
    try {
      const { data } = q ? await api.get('/registrar/certificates/search', { params: { query: q } })
                         : await api.get('/registrar/certificates')
      setCerts(data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  function handleSearch(e) {
    e.preventDefault()
    load(query)
  }

  async function revoke(e) {
    e.preventDefault()
    await api.post(`/registrar/certificates/${revokeTarget.id}/revoke`, { reason })
    setRevokeTarget(null)
    setReason('')
    load(query)
  }

  async function reissue(id) {
    await api.post(`/registrar/certificates/${id}/reissue`)
    load(query)
  }

  return (
    <div>
      <form onSubmit={handleSearch} className="flex gap-2 mb-6">
        <input className="input-field" placeholder="Search by student number, name, or certificate ID"
               value={query} onChange={(e) => setQuery(e.target.value)} />
        <button className="btn-outline">Search</button>
        <button type="button" className="btn-outline" onClick={() => { setQuery(''); load() }}>Reset</button>
      </form>

      {loading ? <p className="text-ledger-slate text-sm">Loading…</p> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ledger-navy text-ledger-parchment text-left">
              <tr>
                <th className="px-4 py-3">Student</th>
                <th className="px-4 py-3">Program</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Issued</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {certs.map((c) => (
                <tr key={c.id} className="border-t border-black/5 align-top">
                  <td className="px-4 py-3">{c.studentName}<div className="text-xs text-ledger-slate">{c.studentNumber}</div></td>
                  <td className="px-4 py-3">{c.programName}</td>
                  <td className="px-4 py-3"><span className={`badge ${c.status === 'ACTIVE' ? 'badge-verified' : 'badge-revoked'}`}>{c.status}</span></td>
                  <td className="px-4 py-3 text-ledger-slate">{c.issueDate}</td>
                  <td className="px-4 py-3 space-x-3 whitespace-nowrap">
                    {c.status === 'ACTIVE' && (
                      <button className="text-ledger-revoked text-xs underline" onClick={() => setRevokeTarget(c)}>Revoke</button>
                    )}
                    {c.status !== 'REISSUED' && (
                      <button className="text-ledger-navy text-xs underline" onClick={() => reissue(c.id)}>Reissue</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {revokeTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form onSubmit={revoke} className="card p-6 w-full max-w-sm space-y-4">
            <h3 className="font-display text-lg">Revoke Certificate</h3>
            <p className="text-sm text-ledger-slate">{revokeTarget.studentName} — {revokeTarget.programName}</p>
            <textarea required className="input-field" rows="3" placeholder="Reason for revocation"
                      value={reason} onChange={(e) => setReason(e.target.value)} />
            <div className="flex gap-2 justify-end">
              <button type="button" className="btn-outline" onClick={() => setRevokeTarget(null)}>Cancel</button>
              <button type="submit" className="bg-ledger-revoked text-white px-5 py-2.5 rounded-sm">Confirm Revoke</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------

function OnboardStudent() {
  const [form, setForm] = useState({ username: '', email: '', fullName: '', studentNumber: '', departmentCode: '', programName: '', enrollmentYear: '', graduationYear: '' })
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const payload = { ...form, enrollmentYear: Number(form.enrollmentYear), graduationYear: form.graduationYear ? Number(form.graduationYear) : null }
      const { data } = await api.post('/registrar/students', payload)
      setResult(data)
      setForm({ username: '', email: '', fullName: '', studentNumber: '', departmentCode: '', programName: '', enrollmentYear: '', graduationYear: '' })
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not create student account')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-lg">
      <form onSubmit={submit} className="card p-6 space-y-4">
        {error && <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm">{error}</div>}
        {['username', 'email', 'fullName', 'studentNumber', 'departmentCode', 'programName'].map((field) => (
          <div key={field}>
            <label className="label-eyebrow block mb-1.5">{field.replace(/([A-Z])/g, ' $1')}</label>
            <input required={field !== 'departmentCode'} className="input-field" value={form[field]}
                   onChange={(e) => setForm({ ...form, [field]: e.target.value })} />
          </div>
        ))}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label-eyebrow block mb-1.5">Enrollment Year</label>
            <input type="number" required className="input-field" value={form.enrollmentYear} onChange={(e) => setForm({ ...form, enrollmentYear: e.target.value })} />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Graduation Year</label>
            <input type="number" className="input-field" value={form.graduationYear} onChange={(e) => setForm({ ...form, graduationYear: e.target.value })} />
          </div>
        </div>
        <button className="btn-primary w-full" disabled={loading}>{loading ? 'Creating…' : 'Create Student Account'}</button>
      </form>

      {result && (
        <div className="card p-6 mt-4 border-t-4 border-ledger-verified text-sm">
          <p className="font-medium mb-2">Student account created.</p>
          <p>Username: <span className="font-mono">{result.username}</span></p>
          <p>Temporary password: <span className="font-mono">{result.temporaryPassword}</span></p>
          <p className="text-xs text-ledger-slate mt-2">Share this password securely — it will not be shown again.</p>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------

function AuditLogs() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/registrar/audit-logs').then(({ data }) => setLogs(data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <p className="text-ledger-slate text-sm">Loading…</p>

  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-ledger-navy text-ledger-parchment text-left">
          <tr>
            <th className="px-4 py-3">Actor</th>
            <th className="px-4 py-3">Action</th>
            <th className="px-4 py-3">Target</th>
            <th className="px-4 py-3">Details</th>
            <th className="px-4 py-3">When</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l) => (
            <tr key={l.id} className="border-t border-black/5">
              <td className="px-4 py-3">{l.actorUsername}</td>
              <td className="px-4 py-3 font-mono text-xs">{l.action}</td>
              <td className="px-4 py-3 text-xs">{l.targetType} {l.targetId}</td>
              <td className="px-4 py-3 text-ledger-slate">{l.details}</td>
              <td className="px-4 py-3 text-ledger-slate">{new Date(l.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
