import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const userInfo = await login(username, password)
      const path = { STUDENT: '/student', REGISTRAR: '/registrar', ADMIN: '/admin', EMPLOYER: '/employer' }[userInfo.role] || '/'
      navigate(path)
    } catch (err) {
      setError(err?.response?.data?.message || 'Invalid username or password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto mt-12">
      <div className="text-center mb-8">
        <h1 className="font-display text-3xl text-ledger-navy">Sign in to CertChain</h1>
        <p className="text-ledger-slate mt-2 text-sm">Registrar, Student, and Employer portal access</p>
      </div>

      <form onSubmit={handleSubmit} className="card p-8 space-y-5">
        {error && (
          <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm">{error}</div>
        )}

        <div>
          <label className="label-eyebrow block mb-1.5">Username</label>
          <input
            className="input-field"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            autoFocus
          />
        </div>

        <div>
          <label className="label-eyebrow block mb-1.5">Password</label>
          <input
            type="password"
            className="input-field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? 'Signing in…' : 'Sign in'}
        </button>

        <p className="text-xs text-ledger-slate text-center pt-2">
          Just need to verify a credential? <a href="/verify" className="text-ledger-navy underline">Use the public verification portal</a> — no account required.
        </p>
      </form>
    </div>
  )
}
