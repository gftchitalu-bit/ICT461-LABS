import React, { useEffect, useState } from 'react'
import api from '../../api/axios'

function CertificateCard({ cert, onShare }) {
  const [downloading, setDownloading] = useState(false)

  async function download(kind) {
    setDownloading(true)
    try {
      const url = kind === 'pdf' ? `/student/certificates/${cert.id}/pdf` : `/student/certificates/${cert.id}/qr`
      const { data } = await api.get(url, { responseType: 'blob' })
      const blobUrl = window.URL.createObjectURL(new Blob([data]))
      const a = document.createElement('a')
      a.href = blobUrl
      a.download = kind === 'pdf' ? `certificate-${cert.certificateUid}.pdf` : `qr-${cert.certificateUid}.png`
      a.click()
      window.URL.revokeObjectURL(blobUrl)
    } finally {
      setDownloading(false)
    }
  }

  return (
    <div className="card p-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-display text-lg">{cert.programName}{cert.classification ? ` — ${cert.classification}` : ''}</h3>
          <p className="text-ledger-slate text-sm mt-1">Issued {cert.issueDate}</p>
        </div>
        <span className={`badge ${cert.status === 'ACTIVE' ? 'badge-verified' : 'badge-revoked'}`}>{cert.status}</span>
      </div>

      <div className="mt-3 text-xs font-mono text-ledger-slate break-all">{cert.certificateUid}</div>

      <div className="flex gap-2 mt-5 flex-wrap">
        <button className="btn-outline text-sm" onClick={() => download('pdf')} disabled={downloading}>Download PDF</button>
        <button className="btn-outline text-sm" onClick={() => download('qr')} disabled={downloading}>Download QR</button>
        <button className="btn-gold text-sm" onClick={() => onShare(cert)}>Create Share Link</button>
      </div>
    </div>
  )
}

export default function StudentDashboard() {
  const [certificates, setCertificates] = useState([])
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [shareTarget, setShareTarget] = useState(null)
  const [validHours, setValidHours] = useState(72)

  async function loadAll() {
    setLoading(true)
    try {
      const [certRes, linkRes] = await Promise.all([
        api.get('/student/certificates'),
        api.get('/student/share-links'),
      ])
      setCertificates(certRes.data)
      setLinks(linkRes.data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadAll() }, [])

  async function createLink(e) {
    e.preventDefault()
    await api.post('/student/share-links', { certificateId: shareTarget.id, validForHours: Number(validHours) })
    setShareTarget(null)
    loadAll()
  }

  async function revokeLink(id) {
    await api.post(`/student/share-links/${id}/revoke`)
    loadAll()
  }

  if (loading) return <p className="text-ledger-slate">Loading your certificates…</p>

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-2xl text-ledger-navy mb-1">My Certificates</h1>
        <p className="text-ledger-slate text-sm mb-6">Download official copies or share time-limited, revocable verification links with employers.</p>

        {certificates.length === 0 ? (
          <p className="text-ledger-slate text-sm">No certificates have been issued to you yet.</p>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {certificates.map((c) => (
              <CertificateCard key={c.id} cert={c} onShare={setShareTarget} />
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="font-display text-xl text-ledger-navy mb-4">Shareable Links</h2>
        {links.length === 0 ? (
          <p className="text-ledger-slate text-sm">You haven't created any shareable links yet.</p>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-ledger-navy text-ledger-parchment text-left">
                <tr>
                  <th className="px-4 py-3">Link</th>
                  <th className="px-4 py-3">Expires</th>
                  <th className="px-4 py-3">Accessed</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {links.map((l) => (
                  <tr key={l.id} className="border-t border-black/5">
                    <td className="px-4 py-3 font-mono text-xs break-all max-w-xs">{l.verifyUrl}</td>
                    <td className="px-4 py-3 text-ledger-slate">{new Date(l.expiresAt).toLocaleString()}</td>
                    <td className="px-4 py-3">{l.accessCount}×</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${l.revoked ? 'badge-revoked' : 'badge-verified'}`}>
                        {l.revoked ? 'Revoked' : 'Active'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {!l.revoked && (
                        <button className="text-ledger-revoked text-xs underline" onClick={() => revokeLink(l.id)}>Revoke</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {shareTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form onSubmit={createLink} className="card p-6 w-full max-w-sm space-y-4">
            <h3 className="font-display text-lg">Share "{shareTarget.programName}"</h3>
            <div>
              <label className="label-eyebrow block mb-1.5">Valid for how many hours?</label>
              <input type="number" min="1" className="input-field" value={validHours} onChange={(e) => setValidHours(e.target.value)} />
            </div>
            <div className="flex gap-2 justify-end">
              <button type="button" className="btn-outline" onClick={() => setShareTarget(null)}>Cancel</button>
              <button type="submit" className="btn-primary">Create Link</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}
