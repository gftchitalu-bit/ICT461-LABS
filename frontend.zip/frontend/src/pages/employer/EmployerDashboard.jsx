import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import VerifyPortal from '../VerifyPortal'

export default function EmployerDashboard() {
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/employer/history')
      .then(({ data }) => setHistory(data))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="space-y-10">
      <VerifyPortal />

      <div>
        <h2 className="font-display text-xl text-ledger-navy mb-4">Your Verification History</h2>
        {loading ? (
          <p className="text-ledger-slate text-sm">Loading…</p>
        ) : history.length === 0 ? (
          <p className="text-ledger-slate text-sm">You haven't verified any credentials yet.</p>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-ledger-navy text-ledger-parchment text-left">
                <tr>
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">Program</th>
                  <th className="px-4 py-3">Method</th>
                  <th className="px-4 py-3">Result</th>
                  <th className="px-4 py-3">When</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h) => (
                  <tr key={h.id} className="border-t border-black/5">
                    <td className="px-4 py-3">{h.studentName || '—'}</td>
                    <td className="px-4 py-3">{h.programName || '—'}</td>
                    <td className="px-4 py-3">{h.method}</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${h.result === 'VERIFIED' ? 'badge-verified' : 'badge-revoked'}`}>
                        {h.result}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-ledger-slate">{new Date(h.verifiedAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
