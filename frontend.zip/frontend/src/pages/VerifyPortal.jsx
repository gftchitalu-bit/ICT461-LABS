import React, { useEffect, useState } from 'react'
import { useParams, useLocation } from 'react-router-dom'
import api from '../api/axios'

const RESULT_STYLES = {
  VERIFIED: { badge: 'badge-verified', label: '✓ Verified', border: 'border-ledger-verified' },
  TAMPERED: { badge: 'badge-revoked', label: '⚠ Tampered / Integrity Failure', border: 'border-ledger-revoked' },
  REVOKED: { badge: 'badge-revoked', label: '✕ Revoked', border: 'border-ledger-revoked' },
  NOT_FOUND: { badge: 'badge-neutral', label: '? Not Found', border: 'border-ledger-slate' },
  EXPIRED_LINK: { badge: 'badge-neutral', label: '⏱ Link Expired', border: 'border-ledger-slate' },
}

function ResultCard({ result }) {
  if (!result) return null
  const style = RESULT_STYLES[result.result] || RESULT_STYLES.NOT_FOUND

  return (
    <div className={`card p-6 border-t-4 ${style.border} mt-6`}>
      <span className={`badge ${style.badge} text-sm`}>{style.label}</span>
      <p className="text-ledger-slate mt-3 text-sm">{result.message}</p>

      {result.certificateUid && (
        <div className="grid grid-cols-2 gap-4 mt-5 text-sm">
          {result.studentName && (
            <div><div className="label-eyebrow">Owner</div><div>{result.studentName}</div></div>
          )}
          {result.studentNumber && (
            <div><div className="label-eyebrow">Student Number</div><div>{result.studentNumber}</div></div>
          )}
          {result.programName && (
            <div><div className="label-eyebrow">Certificate</div><div>{result.programName}{result.classification ? ` (${result.classification})` : ''}</div></div>
          )}
          {result.issueDate && (
            <div><div className="label-eyebrow">Issued</div><div>{result.issueDate}</div></div>
          )}
          <div><div className="label-eyebrow">Certificate ID</div><div className="font-mono text-xs break-all">{result.certificateUid}</div></div>
          {result.transactionId && (
            <div><div className="label-eyebrow">Blockchain Transaction</div><div className="font-mono text-xs break-all">{result.transactionId}</div></div>
          )}
          {result.blockHash && (
            <div className="col-span-2"><div className="label-eyebrow">Ledger Block Hash</div><div className="font-mono text-xs break-all">{result.blockHash}</div></div>
          )}
          <div><div className="label-eyebrow">Ledger Integrity</div><div>{result.chainIntact ? 'Intact' : 'FAILED — do not trust'}</div></div>
        </div>
      )}
    </div>
  )
}

export default function VerifyPortal() {
  const { certificateUid, token } = useParams()
  const location = useLocation()
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [manualId, setManualId] = useState('')
  const [file, setFile] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    if (certificateUid) {
      runVerify(() => api.get(`/verify/${certificateUid}`))
    } else if (token) {
      runVerify(() => api.get(`/verify/link/${token}`))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [certificateUid, token])

  async function runVerify(call) {
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const { data } = await call()
      setResult(data)
    } catch (err) {
      setError(err?.response?.data?.message || 'Could not reach the verification service.')
    } finally {
      setLoading(false)
    }
  }

  function handleManualSubmit(e) {
    e.preventDefault()
    const trimmed = manualId.trim()
    if (!trimmed) return
    runVerify(() => api.get(`/verify/${trimmed}`))
  }

  function handleUploadSubmit(e) {
    e.preventDefault()
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)
    runVerify(() => api.post('/verify/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }))
  }

  const isAutoMode = Boolean(certificateUid || token)

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="font-display text-3xl text-ledger-navy">Verify a Credential</h1>
        <p className="text-ledger-slate mt-2 text-sm">
          Confirm the authenticity of a Mulungushi University certificate against the permissioned ledger.
        </p>
      </div>

      {!isAutoMode && (
        <div className="card p-6 space-y-6">
          <form onSubmit={handleManualSubmit} className="space-y-3">
            <label className="label-eyebrow block">Enter Certificate ID</label>
            <div className="flex gap-2">
              <input
                className="input-field"
                placeholder="e.g. 3f9a1c2e-4b6d-4e2a-9c1a-8d7e6f5a4b3c"
                value={manualId}
                onChange={(e) => setManualId(e.target.value)}
              />
              <button className="btn-primary shrink-0">Verify</button>
            </div>
          </form>

          <div className="border-t border-black/10" />

          <form onSubmit={handleUploadSubmit} className="space-y-3">
            <label className="label-eyebrow block">Or Upload a Certificate PDF</label>
            <div className="flex gap-2">
              <input
                type="file"
                accept="application/pdf"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                className="input-field"
              />
              <button className="btn-outline shrink-0" disabled={!file}>Verify</button>
            </div>
          </form>

          <p className="text-xs text-ledger-slate">
            Tip: scanning the QR code printed on a certificate opens its verification page directly — no typing required.
          </p>
        </div>
      )}

      {loading && <p className="text-center text-ledger-slate mt-6">Checking the ledger…</p>}
      {error && <div className="bg-ledger-revoked/10 text-ledger-revoked text-sm px-4 py-3 rounded-sm mt-6">{error}</div>}
      <ResultCard result={result} />
    </div>
  )
}
